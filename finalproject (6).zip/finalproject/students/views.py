from django.shortcuts import render
from django.http import HttpResponse
from students.models import studentdetails #studentenrollment
from students.models import coursedetails
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def home(request):
    context = {'firstname':'Kaylee', 'lastname':'Frazier'}
    return render(request, 'students/home.html', context)

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

@login_required
def studentinfo(request):
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM students_studentdetails')
    students = dictfetchall(cursor)
    paginator = Paginator(students, 10)
    page = request.GET.get('page')
    studentdata = paginator.get_page(page)
    return render(request, 'students/studentdetails.html', {'data': studentdata})

@login_required
def studentenrollment(request):
    student = studentdetails.objects.all()
    cdata = coursedetails.objects.all()
    
    if('studentid' in request.session):
        cdata = studentenrollment.objects.filter(studentid = request.session['studentid'])
    if('sid' in request.GET and 'cid' not in request.GET):
        sid = request.GET.get('sid')
        request.session['studentid'] = sid
        return HttpResponse('Success')
    if('sid' in request.GET and 'cid' in request.GET):
        sid = request.GET.get('sid')
        cid = request.GET.get('cid')
        cdata = studentenrollment.objects.filter(studentid = sid)
        for row in cdata:
            if row.studentenrollment == cid:
                return HttpResponse('Error')
        newdata = Course(studentid = sid, courseid = cid)
        newdata.save()
        return HttpResponse("Success")
    return render(request, 'students/studentenrollment.html', {'student':student, 'course':cdata})

@login_required
def courseinfo(request):
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM students_coursedetails')
    courses = dictfetchall(cursor)
    paginator = Paginator(courses, 10)
    page = request.GET.get('page')
    coursedata = paginator.get_page(page)
    return render(request, 'students/coursedetails.html', {'info' : coursedata})