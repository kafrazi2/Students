from django.db import models

class studentdetails(models.Model):
    studentid = models.IntegerField()
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.TextField()
    year = models.CharField(max_length=500)
    gpa = models.DecimalField(max_digits=4, decimal_places=2)

class coursedetails(models.Model):
    courseid = models.IntegerField()
    coursetitle = models.CharField(max_length=500)
    coursename = models.TextField()
    coursesectioncode = models.IntegerField()
    coursedepartment = models.TextField()
    instructorfullname = models.TextField()

class studentenrollment(models.Model):
    studentid = models.IntegerField()
    courseid = models.IntegerField()
    coursetitle = models.CharField(max_length=500)
    coursename = models.TextField()
    coursesectioncode = models.IntegerField()
    coursedepartment = models.TextField()
    instructorfullname = models.TextField()
# Create your models here.
