from django.contrib import admin
from students.models import studentdetails
from students.models import coursedetails

admin.site.register(studentdetails)
admin.site.register(coursedetails)
# Register your models here.
